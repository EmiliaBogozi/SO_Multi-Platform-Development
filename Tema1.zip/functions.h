
/*Definirea structurii unui nod din HashMap*/
typedef struct node {
	char *symbol;
	char *mapping;
} node;

/*Definirea structurii unei liste dublu inlantuite*/
typedef struct list {
	char *value;
	struct list *next;
	struct list *prev;
} list;

/*Definirea structurii de HashMap*/
typedef struct HashMap {
	int size;
	struct node **list;
} HashMap;

HashMap* initHashMap(int size);
void initList(list **a);
void insert(HashMap *h, char *symbol, char *mapping);
void delete(HashMap *h, char *symbol);
void addListFirst(list **l, char *new_value);
void addList(list **a, char *new_value);
void free_HashMap(HashMap *h);
void free_list(list *l);
void replaceWord(char *str, char *oldWord, char *newWord);
int decode(char *c);
void define_args(char *argv[], int *i, HashMap **h);
void include_args(char *argv[], int *i, list **l);
void include(list *l, int write_file, FILE *fwrite, HashMap *h,
	char *line[]);
void define(HashMap **h, char *line[]);
void undefine(HashMap **h, char **token);
void check_if_else(char *copy_line, char *line[], int cond_check,
	int write_file, FILE *fwrite, HashMap *h);
void if_else(FILE *fread, FILE *fwrite, int write_file, HashMap *h,
	char *line[]);
char *search_path(char *c);
int check_message(char *line, char *symbol);
void text(char **token, char *line, HashMap *h, int write_file,
	FILE *fwrite);
void if_def(HashMap *h, FILE *fread, FILE *fwrite, int write_file,
	char *line[]);
void if_ndef(HashMap *h, FILE *fread, FILE *fwrite, int write_file,
	char *line[], list *l);
void include(list *l, int write_file, FILE *fwrite, HashMap *h,
	char *line[]);
void check_command(HashMap *h, int write_file, char line[256],
	FILE *fwrite, FILE *fread, list *l);
int decode_args(char *a);
char *delLastFile(char *name);
